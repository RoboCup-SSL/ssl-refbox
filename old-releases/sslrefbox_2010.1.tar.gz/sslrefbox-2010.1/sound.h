#ifndef SOUND_H
#define SOUND_H

extern void sound_play(const char* fname);

#endif
