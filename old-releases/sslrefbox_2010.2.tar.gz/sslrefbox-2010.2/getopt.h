#ifndef GETOPT_ISDEF
#define GETOPT_ISDEF
extern char	*optarg;	
int getopt(int nargc, char * const *nargv, char* ostr);
#endif
