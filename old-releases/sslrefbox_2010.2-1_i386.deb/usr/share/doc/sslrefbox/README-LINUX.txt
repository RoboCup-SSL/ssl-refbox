For Debian Systems (Debian, Unbuntu, Knoppix, ...)
--------------------------------------------------

    As root install compiler and libraries:
    # apt-get install libgtkmm-2.4-dev make g++

    As normal user compile:
    $ make

    As root install:
    # make install
