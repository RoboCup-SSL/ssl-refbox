#ifndef LOGFILE_H
#define LOGFILE_H

#include <string>
#include <exception>
#include "gameinfo.h"

class Logfile
{
protected:
    FILE *file;
public:

    enum exception {FILE_OPEN_ERROR,FILE_WRITE_ERROR};

    Logfile(const std::string& filename) throw(exception);
    ~Logfile();

    /**
     * log a message. see printf(3) for format string and argument list.
     */
    void log(const char* format, ...) throw (exception);
};

#endif
