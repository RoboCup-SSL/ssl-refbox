#include <assert.h>
#include <cstdio>

#include "logfile.h"

Logfile::Logfile(const std::string& filename) throw (exception)
{
    printf("============== %s\n", filename.c_str());
    file=fopen(filename.c_str(), "w");
    if (NULL==file)
    {
        perror("logfile: fopen failed");
        throw(Logfile::FILE_OPEN_ERROR);
    }
}

Logfile::~Logfile()
{
    if(file)
    {
        if(-1 == fclose(file))
        {
            perror("logfile: close failed");
        }
    }
}


void Logfile::log(const char* fmt, ...) throw (exception)
{
    va_list ap;
    assert(file >= 0);
    va_start(ap,fmt);

    vprintf(fmt,ap);

    if(vfprintf(file, fmt, ap) < 0)
    {
        perror("logfile write failed");
        throw(Logfile::FILE_WRITE_ERROR);
    }

//     if(fprintf(logfile, "\n") < 0)
//     {
//         throw(Logfile::FILE_WRITE_ERROR);
//     }

    va_end(ap);
}
